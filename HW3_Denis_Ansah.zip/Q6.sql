USE [pubs]
GO

select t.[title_id] ,t.[title]
  group by (a.[au_fname] order by [authors].[au_fname]) authors
  from [dbo].[titles] t
  inner join [dbo].[titleauthor] ta
  on t.title_id = ta.title_id
  inner join [dbo].[authors] a
  on ta.au_id = a.au_id
  group by a.title_id, a.title
GO
