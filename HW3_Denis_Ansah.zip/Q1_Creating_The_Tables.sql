/*I am using my AdventureWorks2014_OLTP database*/
USE [AdventureWorks2014_OLTP]
GO

/*I check to see if I havent previously created the tables*/
IF OBJECT_ID('HumanResources.Employee_Males', 'U') IS NOT NULL 
  DROP TABLE HumanResources.Employee_Males; 
IF OBJECT_ID('HumanResources.Employee_Females', 'U') IS NOT NULL 
  DROP TABLE HumanResources.Employee_Females; 

/*I create the tables using varchar for the data types for simplicity*/
CREATE TABLE [HumanResources].[Employee_Males](
	[FirstName] [varchar](50),
	[LastName]  [varchar](50),
	[Domain]    [varchar](50),
	[Login]     [varchar](50)
	)
GO
CREATE TABLE [HumanResources].[Employee_Females](
	[FirstName] [varchar](50),
	[LastName]  [varchar](50),
	[Domain]    [varchar](50),
	[Login]     [varchar](50)
	)
GO